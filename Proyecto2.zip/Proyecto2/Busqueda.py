class Busqueda:
    
    def BFS(self, s):
        pass

    def DFS_R(self, s):
        pass

    def DFS_I(self, s):
        pass

    def BusquedaAncho(self, graph, start, end):
        path = [start]
        queue = [path]
        # Recorrer toda la fila
        
        while queue:
            current_path = queue.pop(0)
            if current_path[-1] == end:
                return current_path
            
            for next_vertex in graph.get_neighbours(current_path[-1]):
                if next_vertex not in current_path:
                    new_path = current_path + [next_vertex]
                    queue.append(new_path)

    for v in path:
        print(f'{v.get_Name()} ', end=' -> ')
    def BusquedaProfundo(self, graph, start, end, path):
        path.append(start)
        #Caso base:
        if start == end:
            return path

        for v in graph.get_neighbours(start):
            if v not in path:
                new_path = self.BusquedaProfundo(graph, v, end, path)
                if (new_path is not None):
                    return new_path
            
    for v in path:
        print(f'{v.get_Name()} ', end=' -> ')
    def BusquedaRecursiva(self):
        pass