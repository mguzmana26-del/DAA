from Nodo import Nodo
from Arista import Arista
import random

class Grafo:
    def __init__(self):
        self.id = ""
        self.nodos   ={}
        self.aristas ={}
        self.vecinos = {}
        self.nodosBFS = {}
        self.aristasBFS = {}
        self.vecinosBFS = {}
        self.nodosDFS_R = {}
        self.aristasDFS_R = {}
        self.vecinosDFS_R = {}
        self.visitedDSF_R = set()
        self.edges_written_DFS_R = set()
        self.nodosDFS_I = {}
        self.aristasDFS_I = {}
        self.vecinosDFS_I = {}
        self.path = []
    
    def addNodo(self, nombre):
        nodo = self.nodos.get(nombre)
        #print("EL nodo es: ", nodo)
        if nodo is None:
            nodo = Nodo(nombre)
            #print("EL nodo despues es: ", nodo.dato)
            self.nodos[nombre] = nodo
            #print("Nodos totales: ", self.nodos)
        #else:
        #    return
        return nodo

    def addEdge(self, nombre, nodo0, nodo1):
        arista = self.aristas.get(nombre)
        #print("La arista es: ", arista, nombre)
        #print("La arista despues es: ", arista.id)
        e = self.aristas.get(nombre)
        if e is None:
            #self.aristas[nombre] = arista.id
            n0 = self.addNodo(nodo0)
            n1 = self.addNodo(nodo1)
            arista = Arista(n0, n1, nombre)
            self.aristas[nombre] = arista
            self.vecinos.setdefault(nodo0, []).append(nodo1)
            self.vecinos.setdefault(nodo1, []).append(nodo0)
        #print("Arista totales: ", self.aristas)
        return arista
    
    # Crea el archivo con el nombre 'grafo.gv'
    def getGraph(self, filename):
        with open(filename, "w") as file:
            file.write("graph G {\n")
            connector = "--"

            for arista in self.aristas.values():
                n0 = arista.n0.dato
                n1 = arista.n1.dato
                file.write(f"    {n0} {connector} {n1};\n")

            file.write("}\n")
    
    def getArista(self, name):
        return self.aristas.get(name)
    
    def getAristas(self):
        return self.aristas
    
    def getRandomArista(self):
        return random.choice(list(self.aristas.values()))
    
    def getRandomNodo(self):
        return random.choice(list(self.nodos.keys()))
    #----------------------------------------------------
    # Algoritmos de busqueda
    # ---------------------------------------------------
    def getVecinos(self, nodo):
        return self.vecinos.get(nodo, [])

    def BFS(self, s):
        visited = set([s])
        queue = [s]
        edges_written = set()
        while queue:
            node = queue.pop(0)
            for vecino in self.getVecinos(node):
                if vecino not in visited:
                    visited.add(vecino)
                    queue.append(vecino)
                    edge = tuple(sorted((node, vecino)))
                    if edge not in edges_written:
                        nombre = str(edge[0])+'--'+str(edge[1])
                        nodo0 = edge[0]
                        nodo1 = edge[1]
                        edges_written.add(edge)
                        e = self.aristasBFS.get(nombre)
                        if e is None:
                            n0 = self.addNodo(nodo0)
                            n1 = self.addNodo(nodo1)
                            arista = Arista(n0, n1, nombre)
                            self.aristasBFS[nombre] = arista
                            self.vecinosBFS.setdefault(nodo0, []).append(nodo1)
                            self.vecinosBFS.setdefault(nodo1, []).append(nodo0)
        self.getGraphSearch("BFS.gv", self.aristasBFS)
        return edges_written

    def DFS_R(self, s):
        self.visitedDSF_R.add(s)
        self.path.append(s)
        for v in self.getVecinos(s):
            if v is None:
                return
            #if v not in self.path:
            if v not in self.visitedDSF_R:
                self.visitedDSF_R.add(v)
                node = self.path[-1]
                edge = tuple(sorted((node, v)))
                if edge not in self.edges_written_DFS_R:
                        nombre = str(edge[0])+'--'+str(edge[1])
                        nodo0 = edge[0]
                        nodo1 = edge[1]
                        self.edges_written_DFS_R.add(edge)
                        e = self.aristasDFS_R.get(nombre)
                        if e is None:
                            #n0 = self.nodos.get(nodo0)
                            #n1 = self.nodos.get(nodo1)
                            n0 = self.addNodo(nodo0)
                            n1 = self.addNodo(nodo1)
                            arista = Arista(n0, n1, nombre)
                            self.aristasDFS_R[nombre] = arista
                            self.vecinosDFS_R.setdefault(nodo0, []).append(nodo1)
                            self.vecinosDFS_R.setdefault(nodo1, []).append(nodo0)
                            self.DFS_R(v)
        return self.getGraphSearch('DFS_R.gv', self.aristasDFS_R)

    def DFS_I(self, s):
        visited = set()
        stack = [(s, None)]
        edges_written = set()
        while stack:
            node, parent = stack.pop()
            if node in visited:
                continue
            visited.add(node)
            if parent is not None:
                edge = tuple(sorted((node, parent)))
                if edge not in edges_written:
                    nombre = str(edge[0]) + '--' + str(edge[1])
                    nodo0, nodo1 = edge
                    edges_written.add(edge)
                    n0 = self.addNodo(nodo0)
                    n1 = self.addNodo(nodo1)
                    arista = Arista(n0, n1, nombre)
                    self.aristasDFS_I[nombre] = arista
                    self.vecinosDFS_I.setdefault(nodo0, []).append(nodo1)
                    self.vecinosDFS_I.setdefault(nodo1, []).append(nodo0)

            for vecino in self.getVecinos(node):
                if vecino not in visited:
                    stack.append((vecino, node))
        self.getGraphSearch("DFS_I.gv", self.aristasDFS_I)
        return edges_written
    
    def getGraphSearch(self, filename="path.gv", aristas=[]):
        with open(filename, "w") as file:
            file.write("graph{\n")
            for arista in aristas.values():
                n0 = arista.n0.dato
                n1 = arista.n1.dato
                file.write(f'    {n0} -- {n1};\n')

            file.write("}\n")